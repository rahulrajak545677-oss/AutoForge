# Architecture notes

Android client -> authenticated API gateway -> project service -> AI gateway ->
agent orchestration -> generated project workspace -> isolated build queue ->
Android build worker -> artifact storage -> signed/expiring download URL.

## Security boundaries

- AI provider credentials live only in server secret storage.
- Build workers receive only the project source and short-lived task metadata.
- Never mount host secrets, Docker socket, or other tenants' files into workers.
- Apply CPU, memory, disk, time and network limits.
- Scan dependencies and generated artifacts.
- Require authentication and authorization on every project/build endpoint.

## Next implementation milestones

1. Replace in-memory dictionaries with PostgreSQL.
2. Add Firebase/JWT authentication and per-user authorization.
3. Add durable task queue and progress events.
4. Implement project file generation from validated agent output.
5. Connect isolated build worker and artifact storage.
6. Add test execution, bounded repair iterations and APK verification.
7. Add release signing, audit logging, quotas and cost controls.
