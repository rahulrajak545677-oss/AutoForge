#!/usr/bin/env bash
set -euo pipefail
if [ ! -f settings.gradle ] && [ ! -f settings.gradle.kts ]; then
  echo "ERROR: Android Gradle project not found in /workspace" >&2
  exit 2
fi
gradle --no-daemon --stacktrace assembleDebug
APK="$(find . -path '*/build/outputs/apk/debug/*.apk' -type f | head -n 1)"
if [ -z "$APK" ]; then
  echo "ERROR: Gradle completed but no debug APK was found" >&2
  exit 3
fi
mkdir -p /workspace/artifacts
cp "$APK" /workspace/artifacts/app-debug.apk
sha256sum /workspace/artifacts/app-debug.apk
echo "APK_READY=/workspace/artifacts/app-debug.apk"
