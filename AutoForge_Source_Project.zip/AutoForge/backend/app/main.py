import os, uuid, time
from typing import Dict, Any
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="AutoForge API", version="0.1.0")
PROJECTS: Dict[str, Dict[str, Any]] = {}
TASKS: Dict[str, Dict[str, Any]] = {}

class ProjectRequest(BaseModel):
    name: str = "Untitled app"
    prompt: str = Field(min_length=10, max_length=12000)

@app.get("/health")
def health():
    return {"status": "ok", "service": "autoforge-api"}

@app.post("/projects")
def create_project(body: ProjectRequest):
    project_id = str(uuid.uuid4())
    PROJECTS[project_id] = {
        "id": project_id, "name": body.name, "prompt": body.prompt,
        "status": "created", "created_at": int(time.time())
    }
    return PROJECTS[project_id]

@app.get("/projects/{project_id}")
def get_project(project_id: str):
    if project_id not in PROJECTS:
        raise HTTPException(404, "Project not found")
    return PROJECTS[project_id]

@app.post("/projects/{project_id}/generate")
async def generate_plan(project_id: str):
    project = PROJECTS.get(project_id)
    if not project:
        raise HTTPException(404, "Project not found")

    base = os.getenv("AI_BASE_URL")
    key = os.getenv("AI_API_KEY")
    model = os.getenv("AI_MODEL")
    if not all([base, key, model]):
        raise HTTPException(503, "Managed AI provider is not configured on the server.")

    task_id = str(uuid.uuid4())
    TASKS[task_id] = {"id": task_id, "project_id": project_id, "status": "running"}

    system = (
        "You are AutoForge's Android planning agent. Return a concise, structured "
        "implementation plan for a Kotlin Android app. Include screens, features, "
        "data model, permissions, dependencies, and test plan. Do not claim to have "
        "created or compiled files."
    )
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(
                base.rstrip("/") + "/chat/completions",
                headers={"Authorization": f"Bearer {key}"},
                json={"model": model, "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": project["prompt"]}
                ]}
            )
            response.raise_for_status()
            data = response.json()
            plan = data["choices"][0]["message"]["content"]
        project["plan"] = plan
        project["status"] = "planned"
        TASKS[task_id]["status"] = "completed"
        return {"task_id": task_id, "status": "completed", "plan": plan}
    except Exception as exc:
        TASKS[task_id]["status"] = "failed"
        TASKS[task_id]["error"] = str(exc)
        raise HTTPException(502, "AI provider request failed. Check server logs and provider status.")

@app.get("/tasks/{task_id}")
def get_task(task_id: str):
    task = TASKS.get(task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    return task

@app.post("/projects/{project_id}/build")
def build_project(project_id: str):
    if project_id not in PROJECTS:
        raise HTTPException(404, "Project not found")
    raise HTTPException(501, "Build worker is not wired up in this MVP. No APK has been built.")
