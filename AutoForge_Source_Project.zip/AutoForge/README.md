# AutoForge

AutoForge is a starter implementation of a no-user-API-key Android app builder.
It contains a native Android client, a FastAPI backend, and a Docker-based Android
build worker. The backend owns AI provider credentials; users of the Android app
do not enter API keys.

## Important status

This ZIP is a **starter source project**, not a finished production service.
The Android APK has not been compiled in this environment because Android SDK,
Gradle and an Android build environment are not installed here. No fake APK is
included. Follow the build instructions below on a machine with Android Studio
or use the supplied Docker build worker.

A developer must configure a managed AI provider and pay for its usage. "No-key"
means no personal key is requested from each app user; it does not mean AI has
zero operating cost or works offline.

## Project layout

- `android/` — Kotlin + Jetpack Compose Android client
- `backend/` — FastAPI API, project records, generation orchestration
- `worker/` — isolated Docker build image and build script
- `docs/` — architecture and API notes

## Build Android app

Open `android/` in Android Studio, allow Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s).

The expected debug APK path is:
`android/app/build/outputs/apk/debug/app-debug.apk`

Requirements: Android Studio, JDK 17, Android SDK, Android Gradle Plugin compatible
with the installed Android Studio version.

## Run backend locally

1. Install Python 3.11+.
2. Copy `backend/.env.example` to `backend/.env`.
3. Set `AI_BASE_URL`, `AI_API_KEY` and `AI_MODEL` on the server only.
4. Install dependencies and start the API:

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

The backend uses an OpenAI-compatible chat-completions endpoint as a replaceable
adapter. Keep secrets on the server. Do not put `.env` into the Android project,
APK, Git repository, or ZIP distributed to users.

## Connect Android client

Set `BASE_URL` in `android/app/build.gradle.kts` to your deployed HTTPS backend.
The default is `http://10.0.2.2:8000/` for the Android emulator only. For a physical
phone, use your server's reachable HTTPS URL.

## Build worker

The worker image is a starting point. Run generated code only in isolated,
resource-limited containers with no access to backend secrets, host filesystem,
Docker socket, or other users' data. Review and harden network policy before
production use.

## Current MVP behavior

- Android prompt screen and project list shell
- Backend project creation and generation endpoint
- AI-backed project plan generation when server credentials are configured
- Task status endpoint
- Build endpoint placeholder returning a clear "worker not configured" response

The APK build queue, robust multi-agent orchestration, automated repair loop,
artifact storage, authentication, billing, and production isolation are future
implementation work. Do not treat this starter as production-ready.
