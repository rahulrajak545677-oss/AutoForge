package com.autoforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF090D1B)
private val Panel = Color(0xFF151C32)
private val Purple = Color(0xFF8957FF)
private val Cyan = Color(0xFF45C8F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AutoForgeScreen() }
    }
}

@Composable
fun AutoForgeScreen() {
    var prompt by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Describe an app to get started.") }
    var busy by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Purple,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF111936), Navy, Color(0xFF080B14)))
            ).padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Cyan, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                Text("AutoForge", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("AI BUILDER", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(34.dp))
            Text("Turn your idea", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("into an Android app.", fontSize = 30.sp, fontWeight = FontWeight.Bold,
                color = Cyan)
            Spacer(Modifier.height(10.dp))
            Text("Describe what you want. AutoForge plans the project and prepares the build.",
                color = Color.LightGray, lineHeight = 22.sp)
            Spacer(Modifier.height(26.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("YOUR APP IDEA", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                        placeholder = { Text("Example: Create a music player with playlists, offline playback and a dark theme...") },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF39425B)
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Mic, null, tint = Color.LightGray)
                        Spacer(Modifier.width(6.dp))
                        Text("Voice input planned for a future update", color = Color.Gray, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = {
                            status = if (prompt.isBlank()) "Please describe your app first."
                                     else "Request prepared. Connect this screen to your AutoForge backend to start generation."
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Create my app", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, null, tint = Cyan)
                Spacer(Modifier.width(8.dp))
                Text("DEVELOPMENT PIPELINE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            listOf("Understand idea", "Plan & design", "Generate source code", "Build and verify APK")
                .forEachIndexed { index, label ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Purple.copy(alpha = .2f), shape = RoundedCornerShape(50)) {
                            Text("${index + 1}", Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                                color = Cyan, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(label, color = Color(0xFFE0E5F4))
                    }
                }
            Spacer(Modifier.weight(1f))
            Text(status, color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text("AutoForge MVP • No personal API key in the app",
                color = Color.Gray, fontSize = 10.sp)
        }
    }
}
